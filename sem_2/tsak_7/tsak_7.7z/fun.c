#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "structure.h"
#include "fun.h"


int fun(size_t *n1,size_t n2,struct Student **s1,struct Student**s2)
{
 size_t i,j;
  
 for(i=0;i<*n1;i++)
 {
  for(j=0;j<n2;j++)
  {
   if(  ((*s1)[i].group==(*s2)[j].group) && (strcmp((*s1)[i].name,(*s2)[j].name ))==0  )
   { 
    (*s1)[i].group=(*s1)[*n1-1].group;
    (*s1)[i].rating=(*s1)[*n1-1].rating;
    strcpy( ((*s1)[i].name),(*s1)[*n1-1].name );
    *n1=*n1-1;
    i=0;
      
   }
  }
 } 
return 0; 
}
