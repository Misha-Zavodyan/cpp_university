#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
               
struct Student 
{
 double rating;
 int group;
 char name[512];
};
                                    
struct Groups 
{
int num;
int stud;
};
