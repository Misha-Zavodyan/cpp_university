#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "structure.h"
#include "fun.h"

int main(void)
{int err=0;
 size_t n1=6,n2=3,i;
 struct Student *s1=NULL ;
 struct Student *s2=NULL ;

 err=Input("t1.txt",&s1,&n1);
 if(err==0)
 {  
 err=Input("t2.txt",&s2,&n2);
  if(err==0)
  {  
   fun(&n1,n2,&s1,&s2);
   for(i=0;i<n1;i++) printf("%lg %d %s\n",s1[i].rating,s1[i].group,s1[i].name);
   printf("\n");
   free(s1); free(s2);
  }
 }
 else printf("error");

return err;
}