int Input(const char *filename,struct Student **s, size_t *n);           
int fun(size_t *n1,struct Student **s1);
                                                            
