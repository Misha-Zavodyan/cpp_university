#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
               
struct Student 
{
 int group;
 double rating;
 char name[512];
};
                                    
struct Groups 
{
int num;
int stud;
};
