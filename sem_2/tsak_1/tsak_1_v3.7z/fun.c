#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "fun.h"

int fun(int **a, int *m, int n)
{ int i,j,maxim=a[0][0],maxim_i=0,maxim_i_old=-1;
 for(i=0;i<n;i++){
  for(j=0;j<*m;j++){
   if(a[i][j]>maxim){
    maxim=a[i][j];
    maxim_i=j;
    } 
   }
   if((i>0)&&(maxim_i!=maxim_i_old)){
    maxim_i=-1;
    return 0;
   }
   maxim_i_old=maxim_i;
   if(i<n-1){
    maxim=a[i+1][0];
    maxim_i=0;
   }
  }
 if(maxim_i!=-1){
  *m=*m-1;
  for(i=0;i<n;i++)
   for(j=maxim_i;j<*m;j++){
    a[i][j]=a[i][j+1];
  }
 }
 return 0;
}