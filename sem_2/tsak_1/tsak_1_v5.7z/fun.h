#pragma once
int Input_array(const char *fn, int ***a,int *m, int *n);
int fun(int **a, int *m, int n);
int Output_array(int **a, int m, int n);