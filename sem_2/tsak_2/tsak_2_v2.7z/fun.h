#pragma once
int search(const char *SInputFile, char *smin);
int iscorrect(char *w);

