#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include <string.h>
#include <ctype.h>                                        
#include "fun.h"

int main(void)
{int err; 
 char smin[512];
 smin[0]='0';
 err=search("t.txt",smin);
 if(err==0) 
  if(smin[0]!='0')
   printf("%s",smin);
  else
   printf("Net slowa");
 else printf("error");
 return err;
}