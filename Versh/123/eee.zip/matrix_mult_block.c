#include "array_io.h"

int main(int argc,char *argv[])
{
  int n,m,p,k_a,k_b,ret,task;
  double t;
  char *name_a,*name_b;
  double *a,*b,*c;

  task=10;
  if(!((argc==8 || argc==7 || argc==6) && sscanf(argv[1],"%d",&n)==1 && n>0 && 
  sscanf(argv[2],"%d",&m)==1 && m>0 &&  
  sscanf(argv[3],"%d",&p)==1 && p>=0 && 
  sscanf(argv[4],"%d",&k_a)==1 && k_a>=0))
  {
    printf("Usege: %s n m p k name \n",argv[0]);
    return ERROR_ARGUMENT;
  }

  if(k_a==0)
  {
    name_a = argv[5];
    if(!(sscanf(argv[6],"%d",&k_b)==1 && k_b>=0))
    {
      printf("Usege: %s n m p k name \n",argv[0]);
      return ERROR_ARGUMENT;
    }
    if(k_b==0)
    {
      name_b = argv[7];
    }
  }
  else
  {
    if(!(sscanf(argv[5],"%d",&k_b)==1 && k_b>=0))
    {
      printf("Usege: %s n m p k name \n",argv[0]);
      return ERROR_ARGUMENT;
    }
     if(k_b==0)
    {
      name_b = argv[6];
    }
  }

  a =(double*)malloc(n*n*sizeof(double));
  if (!a)
  {
    printf("not enough memory!\n");
    return ERROR_MEMORY;
  }
  b =(double*)malloc(n*n*sizeof(double));
  if (!b)
  {
    printf("not enough memory!\n");
    return ERROR_MEMORY;
  }
  c =(double*)malloc(n*n*sizeof(double));
  if (!c)
  {
    printf("not enough memory!\n");
    return ERROR_MEMORY;
  }

  if(k_a==0){
    ret=read_matrix(a,n,n,name_a);
  } else {
    ret=init_matrix(a,n,n,k_a);
  }

  if (ret!=SUCCESS)
    {
      switch(ret)
      {
        case ERROR_READ:
          printf("Can't reade %s! \n",name_a);
          break;
        case ERROR_OPEN:
          printf("Can't open %s! \n",name_a);
          break;
        default:
          printf("Unknown error %d in file %s %s",ret, k_a ? "file":"init" ,k_a ? name_a : " ");
      }
      free(a);
      free(b);
      free(c);
      return ret;
    }

  if(k_b==0){
    ret=read_matrix(b,n,n,name_b);
  } else {
    ret=init_matrix(b,n,n,k_b);
  }

  if (ret!=SUCCESS)
    {
      switch(ret)
      {
        case ERROR_READ:
          printf("Can't reade %s! \n",name_b);
          break;
        case ERROR_OPEN:
          printf("Can't open %s! \n",name_b);
          break;
        default:
          printf("Unknown error %d in file %s %s",ret, k_b ? "file":"init" ,k_b ? name_b : " ");
      }
      free(a);
      free(b);
      free(c);
      return ret;
    }

  printf("Initial matrix A:\n");
  print_matrix(a,n,n,p);
  printf("\nInitial matrix B:\n");
  print_matrix(b,n,n,p);
  t=clock();
  matrix_mult_block(a,b,c,n,m);
  t=(clock()-t)/CLOCKS_PER_SEC;
  printf("\nResult matrix C:\n");
  print_matrix(c,n,n,p);
  printf ("%s : Task = %d Elapsed = %.2f\n",argv[0], task, t);
  free(a);
  free(b);
  free(c);
  return SUCCESS;
}