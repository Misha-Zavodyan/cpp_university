#pragma once
int InputArray1(const char *sf, int **m,int *n);
int fun(int *m, int n);
int upr(int* m, int n);