#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "fun.h"

int fun(const char **fnam)
{int x=0,c=0; FILE*f;
 f=fopen(*fnam,"r");
 if (f==NULL)
  return -1;
 fscanf(f,"%d",&x);
 for(int k=0;k<32; k++)
  if(x&(1<<k))
   c++;
   
 if((c%2)==0)
  *fnam="chet";
 else
  *fnam="nechet";
 
 fclose(f);
 return 0;
}