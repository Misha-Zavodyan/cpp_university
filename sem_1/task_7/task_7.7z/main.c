#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "fun.h"

int main(void)
{int err;const char *fnam="t.txt";

 
 err=fun(&fnam);
 if(err==0)
  printf(" %s\n", fnam);
 else if(err==-1)
  printf("No file\n");

 return 0;
}