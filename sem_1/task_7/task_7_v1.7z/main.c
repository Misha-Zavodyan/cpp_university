#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "fun.h"

int main(void)
{int err,z;const char *fnam="t.txt";

 
 err=fun(&fnam,&z);
 if(err==0){
 if (z==1)
  printf("chet\n");
 else
  printf("nechet\n");
 }else if(err==-1)
  printf("No file\n");

 return 0;
}