#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "ann.h"

int fun(int* m, int n,int* len)
{int mini=m[0],k=0,flag=1,ann=0,count=0;
 if(n==0)
  return -1;
 for(int i=1;i<n;++i)
  if(m[i]<mini)
   mini=m[i];

 for(int i=1;i<n-ann;++i)
 {
  if(m[i-1]>m[i])
   flag=1; 
  if(flag==1){
   if(m[i-1]==m[i])
    k++;
   if(m[i-1]<m[i]){
    flag=0;
    
    for(int j=i;j<n-ann;j++){
     m[j-k]=m[j]; 
    }
    for(int j=n-ann;j>n-ann-k;--j)
     m[j]=0;
    
    ann=+k;
    i=i-k;
    m[i-1]=mini;
    k=0;  
   }
  } 
 }
 

 if(flag==1){
    for(int j=n-1-ann;j>n-2-ann-k;--j)
     m[j]=mini+1;
    m[n-2-ann-k]=mini;  
  }


for(int i=0;i<n-ann;++i)
  if(m[i]==mini)
   count++;
   
*len=count;

return 0;
}