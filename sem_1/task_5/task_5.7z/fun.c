#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "ann.h"

int fun(int* m, int n)
{int pos=0, m2[n];
 if(n==0)
  return -1;
 for(int i=0;i<n;++i)
 {
  if(m[i]>0)
  {  
   m[pos]=m[i];
   ++pos;
  }else{
   m2[i-pos]=m[i];
  }  
 }
for(int i=0;i<(n-pos);++i)
 m[i+pos]=m2[i];
     
  

return 0;
}