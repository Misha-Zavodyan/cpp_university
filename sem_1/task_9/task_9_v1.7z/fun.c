#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "ann.h"

int fun(int* m, int n,int* len)
{int i=0; 
 
 for(i=2;i<n;i+=2){
 // printf("%d: %d %d, %d %d \n",i,m[0],m[1],m[i],m[i+1]);
  if(m[i]<=m[0]){
   if(m[0]<m[i+1])
    m[0]=m[i+1];
  }
  else {
   *len=0;
   break;
  }
  if(m[0]>=m[1]){
   *len=1;
   break;
  }
 }
 if((*len==0)||(m[0]<m[1]))
   *len=0;

 return 0;
}