#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "ann.h"
 
int sortt(int* m, int n)
{int j=0,i=0,x=0,y=0;
  if(n==0)
   return -1;
 
 for(i=4;i<n;i+=2){
  x=m[i];
  y=m[i+1];

  j=i-2;
  
  while((x<m[j])){
   m[j+2]=m[j]; 
   m[j+3]=m[j+1];
   j-=2;
   if(j<=0)
    break;
  } m[j+2]=x; m[j+3]=y;
 }

 return 0;
}